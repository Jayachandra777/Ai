//
//  AIToolbox.h
//  AIToolbox
//
//  Created by Kevin Coble on 2/15/15.
//  Copyright (c) 2015 Kevin Coble. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for AIToolbox.
FOUNDATION_EXPORT double AIToolboxVersionNumber;

//! Project version string for AIToolbox.
FOUNDATION_EXPORT const unsigned char AIToolboxVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AIToolbox/PublicHeader.h>


